package com.samsung.bookm.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.samsung.bookm.R;

public class EditBookInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_book_info);
    }
}
