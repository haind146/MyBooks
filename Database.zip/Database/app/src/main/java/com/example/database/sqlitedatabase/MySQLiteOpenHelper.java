package com.example.database.sqlitedatabase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static android.os.Build.ID;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "todo.db";
    public static final int DATABASE_VERSION = 1;
    public static final String TODO_LIST_TABLE = "todo_table";
    public static final String TITLE = "title";
    public static final String ID = "id";
    public static final String DESCRIPTION = "description";
    public static final String TIME = "time";

    public MySQLiteOpenHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_SQL = String.format("CREATE table %s " +
                        "(%s INTEGER PRIMARY KEY AUTOINCREMENT, %s TEXT, %s TEXT, %s LONG)"
                , TODO_LIST_TABLE, ID, TITLE, DESCRIPTION, TIME);
        db.execSQL(CREATE_TABLE_SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String DROP_SQL = String.format("DROP TABLE if EXIST %s", TODO_LIST_TABLE);
        sqLiteDatabase.execSQL(DROP_SQL);
    }
}
