package com.example.database.sqlitedatabase;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.database.R;

import java.util.ArrayList;

public class SQLiteDatabaseActivity extends AppCompatActivity {

    EditText mTitle, mDescription, mTime;
    Button mAdd;
    Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite_database);
        mContext = this;
        mTitle = findViewById(R.id.edit_title);
        mTime = findViewById(R.id.edit_time);
        mDescription = findViewById(R.id.edit_description);
        mAdd = findViewById(R.id.btn_add);

        mAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = mTitle.getText().toString();
                String descrition = mDescription.getText().toString();
                long time = Long.parseLong(mTime.getText().toString());

                AppDatabase.getInstance(mContext).insert(new TODOItem(title, descrition, time));
                Toast.makeText(mContext, "insert done", Toast.LENGTH_LONG).show();
                mTitle.setText("");
                mDescription.setText("");
                mTime.setText("");

                printOutDatabase();

                ArrayList<TODOItem> itemArrayList = AppDatabase.getInstance(mContext).getTodoList();
                TODOItem lastItem = itemArrayList.get(itemArrayList.size()-1);
                lastItem.setTitle("new title " + lastItem.getTitle());
                AppDatabase.getInstance(mContext).update(lastItem);
                Log.d("SVMC", "update");
                printOutDatabase();


                TODOItem firstItem = itemArrayList.get(0);
                AppDatabase.getInstance(mContext).delete(firstItem.getId());
                Log.d("SVMC", "delete");
                printOutDatabase();
            }
        });


    }
    void printOutDatabase() {
        ArrayList<TODOItem> itemArrayList = AppDatabase.getInstance(mContext).getTodoList();

        Log.d("SVMC", "____________________________________");

        for (TODOItem item : itemArrayList) {
            Log.d("SVMC", "id: " + item.getId() + "title: " + item.getTitle() + "\t" + "description: " +item.getDescription());
        }
    }
}
