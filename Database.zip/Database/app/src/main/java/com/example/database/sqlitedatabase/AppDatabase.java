package com.example.database.sqlitedatabase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class AppDatabase  {
    MySQLiteOpenHelper mySQLiteOpenHelper;

    public AppDatabase(Context context) {
        mySQLiteOpenHelper = new MySQLiteOpenHelper(context);
    }

    static AppDatabase instance;

    public static AppDatabase getInstance(Context context) {
        if(instance == null) {
            synchronized (AppDatabase.class) {
                if(instance == null) {
                    instance = new AppDatabase(context);
                }
            }
        }
        return instance;
    }

    public void insert(TODOItem item) {
        SQLiteDatabase sqLiteDatabase = instance.mySQLiteOpenHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MySQLiteOpenHelper.TITLE, item.getTitle());
        contentValues.put(MySQLiteOpenHelper.DESCRIPTION, item.getDescription());
        contentValues.put(MySQLiteOpenHelper.TIME, item.getTime());

        sqLiteDatabase.insert(MySQLiteOpenHelper.TODO_LIST_TABLE, null, contentValues);

    }

    public ArrayList<TODOItem> getTodoList() {
        ArrayList<TODOItem> retArray = new ArrayList<>();
        SQLiteDatabase database = instance.mySQLiteOpenHelper.getReadableDatabase();
        String [] projection = {MySQLiteOpenHelper.ID, MySQLiteOpenHelper.TITLE, MySQLiteOpenHelper.DESCRIPTION, MySQLiteOpenHelper.TITLE};
        Cursor cursor = database.query(MySQLiteOpenHelper.TODO_LIST_TABLE, projection, null, null, null, null, null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String descriptiomn = cursor.getString(2);
            long time = cursor.getLong(3);
            retArray.add(new TODOItem(id, title, descriptiomn, time));

        }

        return retArray;
    }

    public void update(TODOItem item) {
        SQLiteDatabase sqLiteDatabase = instance.mySQLiteOpenHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MySQLiteOpenHelper.ID, item.getId());
        contentValues.put(MySQLiteOpenHelper.TITLE, item.getTitle());
        contentValues.put(MySQLiteOpenHelper.DESCRIPTION, item.getDescription());
        contentValues.put(MySQLiteOpenHelper.TIME, item.getTime());

        String whereClause = MySQLiteOpenHelper.ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(item.getId())};
        sqLiteDatabase.update(MySQLiteOpenHelper.TODO_LIST_TABLE, contentValues, whereClause, whereArgs);
    }

    public void delete(int id) {
        SQLiteDatabase sqLiteDatabase = instance.mySQLiteOpenHelper.getWritableDatabase();
        String whereClause = MySQLiteOpenHelper.ID + " = ?";
        String[] whereArgs = new String[]{String.valueOf(id)};
        sqLiteDatabase.delete(MySQLiteOpenHelper.TODO_LIST_TABLE, whereClause, whereArgs);
    }


}
