package com.example.database;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class SharePreferenceActivity extends AppCompatActivity {

    TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_preference);
        mTextView = findViewById(R.id.tv_first_open);
        SharedPreferences sharedPreferences = getSharedPreferences("my_share_preferrences", MODE_PRIVATE);

        int isFirstOpen = sharedPreferences.getInt("is_first_open", 1);
        mTextView.setText(isFirstOpen + "");

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("is_first_open", 0);
        editor.putString("training_location", "SVMC");
        editor.putLong("training time", 1564451963);
        editor.commit();
    }
}
